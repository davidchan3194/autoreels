# AutoReels

AI-powered reels generator website.

## Development
```bash
npm install
npm run dev
```

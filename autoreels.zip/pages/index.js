export default function Home() {
  return (
    <div style={{ textAlign: "center", padding: "40px" }}>
      <h1>🚀 AutoReels</h1>
      <p>AI-powered Reels Generator for Social Media</p>
      <button style={{ padding: "10px 20px", marginTop: "20px" }}>Get Started</button>
    </div>
  );
}
